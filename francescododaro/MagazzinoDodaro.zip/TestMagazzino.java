package com.nttdata.talent.magazzino;

import java.util.LinkedList;
import java.util.List;

public class TestMagazzino {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Magazzino magazzino = new Magazzino();
		
		LinkedList<Articolo> articoli = magazzino.getArticoli();
		
		for (Articolo articolo: articoli) {
			System.out.println(articolo);
		}
		
		
		
		 String articoloConPrezzoMassimo = trovaMassimo(articoli);
		 System.out.println(articoloConPrezzoMassimo);
		 
		 System.out.println(trovaMassimoPerOgniCategoria(articoli));
		 

	}
	
	public static String trovaMassimo(LinkedList<Articolo> articoli) {
		int badPrice = 0;
		String prodottoCostoMassimo = "";
		for(Articolo articolo: articoli) {
			if(articolo.getPrezzo()>badPrice) {
				badPrice=articolo.getPrezzo();
				prodottoCostoMassimo = articolo.getNome();
			}
		}
		
		return prodottoCostoMassimo;
	}
	
	// deve restituire un array di stringhe, nome dell'articolo con prezzo massimo per ogni categoria
	public static  LinkedList<String> trovaMassimoPerOgniCategoria(LinkedList<Articolo> articoli) {
		LinkedList<String> categorie = new LinkedList<String>();
		categorie.add(articoli.getFirst().getCategoria());
		for(Articolo articolo: articoli) {
				if(!categorie.contains(articolo.getCategoria()))
					categorie.add(articolo.getCategoria());			
		}
		// fare una lista di articoli che siano di una sola categoria

		LinkedList<String> prezzi = new LinkedList<String>();
 		LinkedList<Articolo> articoliStessaClasse = new LinkedList<Articolo>();
 		
 		for(String categoria: categorie) {
 			for(Articolo articolo: articoli) {
				if(articolo.getCategoria().equals(categoria))
				articoliStessaClasse.add(articolo);
 			}
 			prezzi.add(trovaMassimo(articoliStessaClasse)+" "+categoria);
 			articoliStessaClasse.clear();
 		}
 		return prezzi;
 		
	}

}
