package com.nttdata.talentcamp.database;

public class Docente extends Persona {
	private int id;
	private RuoloRicoperto ruolo;
	public Docente(String codiceFiscale, String nome, String cognome, RuoloRicoperto ruolo) {
		super(nome, cognome, codiceFiscale);
		this.ruolo = ruolo;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public RuoloRicoperto getRuolo() {
		return ruolo;
	}
	public void setRuolo(RuoloRicoperto ruolo) {
		this.ruolo = ruolo;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + id;
		result = prime * result + ((ruolo == null) ? 0 : ruolo.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Docente other = (Docente) obj;
		if (id != other.id)
			return false;
		if (ruolo != other.ruolo)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Docente [id=" + id + ", ruolo=" + ruolo + ", getNome()=" + getNome() + ", getCognome()=" + getCognome()
				+ ", getCodiceFiscale()=" + getCodiceFiscale() + ", toString()=" + super.toString() + ", getClass()="
				+ getClass() + "]";
	}
	
	
					
}
