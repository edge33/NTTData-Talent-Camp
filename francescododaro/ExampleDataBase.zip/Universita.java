package com.nttdata.talentcamp.database;

import java.util.List;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

public class Universita {
	private LinkedList<Studente> studenti;
		
	public Universita () {
		this.studenti = new LinkedList<Studente>();
	}

	public void addStudente (Studente studente) {
		this.studenti.add(studente);
	}
	
	public HashSet<Esame> generaListaEsami () {
		HashSet<Esame> listaEsami = new HashSet<Esame>();
		for(Studente studente: studenti) {
			for(Esame esame: studente.getEsami()) {
					listaEsami.add(esame);
			}
		}
		return listaEsami;
	}
	private HashSet<Corso> generaListaCorsi () {
		HashSet<Corso> listaCorsi = new HashSet<Corso>();
		for(Studente studente: studenti) {
			for(Corso corso: studente.getPianoDiStudi()) {
					listaCorsi.add(corso);
			}
		}
		return listaCorsi;
	}
	private HashSet<Docente> generaListaDocenti(){
		HashSet<Docente> docenti = new HashSet<Docente>();
		HashSet<Esame> esami = generaListaEsami();
		for(Esame esame: esami) {
				docenti.add(esame.getDocente());
		}
		return docenti;
	}

	// Per ogni studente, il numero di CFU maturati
	public HashMap<String, Integer> cfuPerStudente(){
		HashMap<String, Integer> cfuStudenti = new HashMap<String, Integer>();
		int cfu = 0;
		for(Studente studente: studenti) {
			cfu = cfuMaturati(studente);
			cfuStudenti.put(studente.getCodiceFiscale(), cfu);
		}
		return cfuStudenti;
	}
	private int cfuMaturati (Studente studente) {
		int cfu = 0;
		for(Esame esame: studente.getEsami()) {
			cfu += esame.getCorso().getCfu();
		}
		return cfu;
	}
	
	// Per ogni studente, la sua media ponderata
	public HashMap<String, Float> mediaStudenti () {
		HashMap<String,Float> medieStudenti = new HashMap<String,Float>();
		for(Studente studente: studenti) {
			medieStudenti.put(studente.getCodiceFiscale(), mediaPonderataStudente(studente));
		}
		return medieStudenti;
	}
	private float mediaPonderataStudente(Studente studente) {
		float sommaVoti = 0;
		for(Esame esame: studente.getEsami()) {
			sommaVoti += esame.getVoto()*esame.getCorso().getCfu();
		}
		return sommaVoti/cfuMaturati(studente);
	}
	
	// Elenco degli studenti che hanno sostenuto tutti gli esami
	public LinkedList<String> laureandi (){
		LinkedList<String> listaLaureandi =  new LinkedList<String>();
		for(Studente studente: studenti) {
			if(studente.getPianoDiStudi().size()==studente.getEsami().size())
				listaLaureandi.add(studente.getCodiceFiscale());
		}
		return listaLaureandi;
	}
	
	// Per ogni corso, gli studenti con i migliori voti	
	public HashMap<String, List<String>> studentiMiglioriPerCorso (){
		HashMap<String, List<String>> studentiMiglioriCorso = new HashMap<String, List<String>>();
		HashSet<Corso> corsi = generaListaCorsi();
		for(Corso corso: corsi) {
			studentiMiglioriCorso.put(corso.getDenominazione(), StudenteMigliore(corso));
		}
		return studentiMiglioriCorso;
	}
	private List<String> StudenteMigliore (Corso corso) {
		List<String> miglioriStudenti = new LinkedList<String>();
		int votoMax = calcolaVotoMax(corso);
		for(Studente studente: studenti) {			
			for(Esame esame: studente.getEsami()) {
				if(esame.getCorso()==corso && esame.getVoto()==votoMax) {
					miglioriStudenti.add(studente.getMatricola());
				}
			}
		}
		return miglioriStudenti;
	}	
	private int calcolaVotoMax (Corso corso) {
		int votoMax=0;
		HashSet<Esame> esami = generaListaEsami();
		for(Esame esame: esami) {
			if(esame.getCorso().equals(corso) && esame.getVoto()>votoMax) {
					votoMax = esame.getVoto();
			}
		}
		return votoMax;
	}
		
	// Per ogni ruolo, il docente che eroga mediamente i voti pi� alti
	public HashMap<RuoloRicoperto, List<String>> docentiBuoni (){
		HashMap<RuoloRicoperto, List<String>> buoniDocenti = new HashMap<RuoloRicoperto, List<String>>();
		for(RuoloRicoperto ruolo: RuoloRicoperto.values()) {
			List<String> docentiBenevoli = new LinkedList<String>();
			HashSet<Docente> docenti = generaListaDocenti();
			float maxMedia = maxMediaDocente(docenti, ruolo);
			docentiBenevoli =  getDocentiBenevoli(docenti, ruolo, maxMedia);
			buoniDocenti.put(ruolo, docentiBenevoli);
		}
		return buoniDocenti;
	}
	private List<String> getDocentiBenevoli(HashSet<Docente> docenti, RuoloRicoperto ruolo, float maxMedia){
		List<String> docentiBenevoli = new LinkedList<String>();
		for(Docente docente: docenti) {
			if(docente.getRuolo().equals(ruolo) && maxMedia == mediaDocente(docente)) {
					docentiBenevoli.add(docente.getCognome());
			}
		}
		return docentiBenevoli;
	}
	private float maxMediaDocente (HashSet<Docente> docenti, RuoloRicoperto ruolo) {
		float maxMedia = 0;
		for(Docente docente: docenti) {
			if(docente.getRuolo().equals(ruolo) && mediaDocente(docente)>maxMedia) {
					maxMedia=mediaDocente(docente);
			}
		}
		return maxMedia;
	}	
	private float mediaDocente (Docente docente) {
		float sommaVoti = 0;
		HashSet<Esame> esami = generaListaEsami();
		for(Esame esame: esami) {
			if(esame.getDocente().equals(docente)) {
				sommaVoti+=esame.getVoto();
			}
		}
		return sommaVoti/esami.size();
	}
	
	// La lista dei corsi per i quali nessuno studente ha sostenuto l�esame
	public LinkedList<String> esamiNonSostenutiDaNessuno (){
		HashSet<Corso> corsi = generaListaCorsi();
		LinkedList<String> esamiNonSostenuti = new LinkedList<String>();
		for(Corso corso: corsi) {
			if(!esameSostenuto(corso))
				esamiNonSostenuti.add(corso.getDenominazione());
		}
		return esamiNonSostenuti;
	}
	private boolean esameSostenuto(Corso corso) {
		for(Studente studente: studenti) {
			for(Esame esame: studente.getEsami()) {
				if(esame.getCorso().equals(corso))
					return true;
			}
		}
		return false;
	}
	
	// La lista dei corsi pi� semplici, ovvero per i quali la media voto � la pi� alta	
	public List<String> corsiFacili (){
		HashSet<Corso> corsi = generaListaCorsi();
		List<String> corsiFacili = new LinkedList<String>();
		float maxMediaCorso = 0;
		for(Corso corso: corsi) {
			if(mediaPerCorso(corso)>maxMediaCorso) {
				maxMediaCorso=mediaPerCorso(corso);
			}
		}
		for(Corso corso: corsi) {
			if(mediaPerCorso(corso)==maxMediaCorso) {
				corsiFacili.add(corso.getDenominazione());
			}
		}
		return corsiFacili;
	}
	private float mediaPerCorso (Corso corso) {
		float media = 0;
		for(Esame esame: esamiPerCorso(corso)) {
			media += esame.getVoto();
		}
		return media/esamiPerCorso(corso).size();
	}
	private List<Esame> esamiPerCorso (Corso corso){
		List<Esame> esamiCorso = new LinkedList<Esame>();
		for(Studente studente: studenti) {
			for(Esame esame: studente.getEsami()) {
				if(esame.getCorso().equals(corso))
					esamiCorso.add(esame);
			}
		}
		return esamiCorso;
	}
	
	// Le matricole degli studenti a cui manca esattamente un esame, e l�esame mancante
	public HashMap<String, List<String>> studenti1EsameMancante (){
		HashMap<String, List<String>> studentiEsameMancante = new HashMap<String, List<String>>();
		for(Studente studente: studenti) {
			if(studente.getEsami().size()==studente.getPianoDiStudi().size()-1) {
				studentiEsameMancante.put(studente.getMatricola(), esameMancante(studente));
			}
		}
		return studentiEsameMancante;
	}	
	private List<String> esameMancante(Studente studente){
		List<Corso> esamiMancanti = new LinkedList<Corso>();
		List<String> nomiEsamiMancanti = new LinkedList<String>();
		for(Corso corso: studente.getPianoDiStudi()) {
			esamiMancanti.add(corso);
		}
		for(Esame esame: studente.getEsami()) {
			if(esamiMancanti.contains(esame.getCorso()))
				esamiMancanti.remove(esame.getCorso());
		}
		for(Corso corso: esamiMancanti) {
			nomiEsamiMancanti.add(corso.getDenominazione());
		}
		return nomiEsamiMancanti;
	}
	

	public LinkedList<Studente> getStudenti() {
		return studenti;
	}

	public void setStudenti(LinkedList<Studente> studenti) {
		this.studenti = studenti;
	}

	@Override
	public String toString() {
		return "Universita [studenti=" + studenti + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((studenti == null) ? 0 : studenti.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Universita other = (Universita) obj;
		if (studenti == null) {
			if (other.studenti != null)
				return false;
		} else if (!studenti.equals(other.studenti))
			return false;
		return true;
	}	
}
