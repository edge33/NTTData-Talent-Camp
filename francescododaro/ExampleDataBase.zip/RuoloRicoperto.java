package com.nttdata.talentcamp.database;

public enum RuoloRicoperto {
	RICERCATORE,
	CONTRATTO,
	TEMPO_INDETERMINATO;
}
