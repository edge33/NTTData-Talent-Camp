package com.nttdata.talentcamp.collection;

public class Articolo {

	private String nome;
	private String categoria;
	private int prezzo;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public int getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(int prezzo) {
		this.prezzo = prezzo;
	}
	@Override
	public String toString() {
		return "Articolo [nome=" + nome + ", categoria=" + categoria + ", prezzo=" + prezzo + "]";
	}
	
	
}
