package com.nttdata.talentcamp.collection;

import java.util.LinkedList;

public class Magazzino {
	
	private LinkedList<Articolo> articoli;

	public Magazzino() {
		this.articoli = new LinkedList<Articolo>();
		String[] categorie = {"cat1", "cat2", "cat3"};
		for(int i = 0; i < 20; i++) {
			int indiceCategoria = (int) (Math.random() * 3);
			Articolo articolo = new Articolo();
			articolo.setNome("articolo " + i);
			articolo.setCategoria(categorie[indiceCategoria]);
			articolo.setPrezzo((int) (Math.random()*100));
			this.articoli.add(articolo);
		}
	}

	public LinkedList<Articolo> getArticoli() {
		return articoli;
	}

	public void setArticoli(LinkedList<Articolo> articoli) {
		this.articoli = articoli;
	}
	
	
}
