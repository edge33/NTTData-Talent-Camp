package com.nttdata.talentcamp.collection;

import java.util.Iterator;
import java.util.LinkedList;

public class Main {

	public static void main(String[] args) {
		Magazzino magazzino = new Magazzino();
		
		LinkedList<Articolo> articoli = magazzino.getArticoli();
	
		for (Articolo articolo : articoli) {
			System.out.println(articolo);
		}
		
		System.out.println();
	
		String articoloConPrezzoMassimo = trovaMassimo(articoli);
		//System.out.println("Articolo con prezzo massimo " + articoloConPrezzoMassimo);
		trovaMassimoPerOgniCategoria(articoli);
	}
	
	/**
	 * restituisce il nome dell'articolo con il prezzo massimo
	 * @param articoli
	 * @return
	 */
	public static String trovaMassimo(LinkedList<Articolo> articoli) {
		int prezzoMassimo = 0;
		String nomeArticoloConPrezzoMassimo = "";
		for(Articolo articolo: articoli) {
			if (articolo.getPrezzo() > prezzoMassimo) {
				prezzoMassimo = articolo.getPrezzo();
				nomeArticoloConPrezzoMassimo = articolo.getNome();
			}
		}
		return nomeArticoloConPrezzoMassimo;
	}
	

	public static String[] trovaMassimoPerOgniCategoria(LinkedList<Articolo> articoli) {
		LinkedList<String> categorie = new LinkedList<String>();
		
		for(Articolo articolo: articoli) {
			if (!giaInserita(categorie, articolo.getCategoria()))
				categorie.add(articolo.getCategoria());
		}
		
		String[] daRestituire = new String[categorie.size()];
		for (int i = 0; i < categorie.size(); i++) {
			//per ogni categoria creo una lista di articoli per questa categoria
			String categoriaCorrente = categorie.get(i);
			LinkedList<Articolo> articoliPerCategoria = costruisciLista(articoli, categoriaCorrente);
			daRestituire[i] = trovaMassimo(articoliPerCategoria);
		}
		
		return daRestituire;
	
	}
		
	private static LinkedList<Articolo> costruisciLista(LinkedList<Articolo> articoli, String categoriaCorrente) {
		LinkedList<Articolo> articoliDaRestituire = new LinkedList<Articolo>();
		for(Articolo articolo: articoli) {
			if (articolo.getCategoria().equals(categoriaCorrente))
				articoliDaRestituire.add(articolo);
		}
		return articoliDaRestituire;
	}

	private static boolean giaInserita(LinkedList<String> categorie, String categoria) {
		for (String categoriaCorrente: categorie) {
			if (categoriaCorrente.equals(categoria))
				return true;
		}
		return false;
	}
	
}
 